using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Dapper;
using Sparcpoint.Core.Abstract;
using Sparcpoint.Core.Models;
using Sparcpoint.SqlServer.Abstractions;

namespace Sparcpoint.Inventory.Database.Data
{
    public class ProductRepository : IProductRepository
    {
        private readonly ISqlExecutor _sqlExecutor;

        public ProductRepository(ISqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor ?? throw new ArgumentNullException(nameof(sqlExecutor));
        }

        public async Task<int> AddProductAsync(ProductCreateRequest request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));

            return await _sqlExecutor.ExecuteAsync(async (conn, trans) =>
            {
                var insertSql = @"
                    INSERT INTO [Instances].[Products] (Name, Description, ProductImageUris, ValidSkus) 
                    VALUES (@Name, @Description, @ProductImageUris, @ValidSkus);
                    SELECT CAST(SCOPE_IDENTITY() AS INT);
";

                var imageJson = JsonSerializer.Serialize(request.ProductImageUris ?? Array.Empty<string>());
                var skusJson = JsonSerializer.Serialize(request.ValidSkus ?? Array.Empty<string>());

                var productId = await conn.ExecuteScalarAsync<int>(
                    insertSql,
                    new { request.Name, request.Description, ProductImageUris = imageJson, ValidSkus = skusJson },
                    trans);

                if (request.Metadata != null && request.Metadata.Count > 0)
                {
                    var attrs = request.Metadata.Select(kv => new { InstanceId = productId, Key = kv.Key, Value = kv.Value }).ToList();
                    await conn.ExecuteAsync(
                        "INSERT INTO [Instances].[ProductAttributes] (InstanceId, [Key], [Value]) VALUES (@InstanceId, @Key, @Value);",
                        attrs,
                        trans);
                }

                if (request.CategoryIds != null && request.CategoryIds.Any())
                {
                    using (var cmd = new SqlCommand("[Instances].[usp_Product_SetCategories]", (SqlConnection)conn, (SqlTransaction)trans))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ProductInstanceId", productId);

                        var dt = new DataTable();
                        dt.Columns.Add("Value", typeof(int));
                        foreach (var id in request.CategoryIds.Distinct())
                            dt.Rows.Add(id);

                        var tvp = new SqlParameter("@CategoryIds", SqlDbType.Structured)
                        {
                            TypeName = "dbo.IntegerList",
                            Value = dt
                        };
                        cmd.Parameters.Add(tvp);

                        await cmd.ExecuteNonQueryAsync();
                    }
                }

                return productId;
            });
        }

        public async Task<IList<ProductSearchResult>> SearchProductsAsync(ProductSearchCriteria criteria)
        {
            return await _sqlExecutor.ExecuteAsync(async (conn, trans) =>
            {
                var sql = @"
                            SELECT p.InstanceId, p.Name, p.Description, p.ProductImageUris, p.ValidSkus
                            FROM [Instances].[Products] p
                            LEFT JOIN [Instances].[ProductCategories] pc ON p.InstanceId = pc.InstanceId
                            LEFT JOIN [Instances].[ProductAttributes] pa ON p.InstanceId = pa.InstanceId
                            WHERE 1=1
                            ";
                var parameters = new DynamicParameters();

                if (!string.IsNullOrWhiteSpace(criteria.Name))
                {
                    sql += " AND p.Name LIKE @Name";
                    parameters.Add("@Name", "%" + criteria.Name + "%");
                }
                if (!string.IsNullOrWhiteSpace(criteria.Description))
                {
                    sql += " AND p.Description LIKE @Description";
                    parameters.Add("@Description", "%" + criteria.Description + "%");
                }
                if (criteria.CategoryIds != null && criteria.CategoryIds.Any())
                {
                    sql += " AND pc.CategoryInstanceId IN @CategoryIds";
                    parameters.Add("@CategoryIds", criteria.CategoryIds.ToArray());
                }
                if (criteria.Metadata != null && criteria.Metadata.Count > 0)
                {
                    int i = 0;
                    foreach (var kv in criteria.Metadata)
                    {
                        sql += $" AND EXISTS (SELECT 1 FROM [Instances].[ProductAttributes] pa{i} WHERE pa{i}.InstanceId = p.InstanceId AND pa{i}.[Key] = @MetaKey{i} AND pa{i}.[Value] = @MetaValue{i})";
                        parameters.Add($"@MetaKey{i}", kv.Key);
                        parameters.Add($"@MetaValue{i}", kv.Value);
                        i++;
                    }
                }

                sql += " GROUP BY p.InstanceId, p.Name, p.Description, p.ProductImageUris, p.ValidSkus";

                var products = await conn.QueryAsync<ProductSearchResult>(sql, parameters, trans);

                // Optionally, load metadata and categories for each product (not shown for brevity)
                return products.ToList();
            });
        }
    }
}